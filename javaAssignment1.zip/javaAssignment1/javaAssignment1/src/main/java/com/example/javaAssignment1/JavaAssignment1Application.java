package com.example.javaAssignment1;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication //marks this class as a spring boot application
public class JavaAssignment1Application {

	public static void main(String[] args) {
		SpringApplication.run(JavaAssignment1Application.class, args);
	}
	//runs the spring boot program
}
