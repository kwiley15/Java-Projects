package com.example.javaAssignment1.Service;


import com.example.javaAssignment1.Repository.ProductRepository;
import com.example.javaAssignment1.product;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service //marks this class as a service component in the spring framework
public class ProductService {


    @Autowired //injects the product repository dependency
    private ProductRepository productRepository; // helps interact with the database


    public product createProduct(product product) {
        return productRepository.save(product);
    } // creates a new product and saves it to the database


    public product getProduct(Long id) {
        return productRepository.findById(id).orElseThrow(() -> new RuntimeException("Product not found"));
    } // retrieve a product by its ID


    public product updateProduct(Long id, product product) {
        product existingProduct = productRepository.findById(id).orElseThrow(() -> new RuntimeException("Product not found"));
        existingProduct.setName(product.getName());
        existingProduct.setDescription(product.getDescription());
        existingProduct.setQuantity(product.getQuantity());
        existingProduct.setPrice(product.getPrice());
        return productRepository.save(existingProduct);
    } // update an existing product details


    public void deleteProduct(Long id) {
        productRepository.deleteById(id);
    } //deletes a product from the database


    public List<product> getAllProducts() {
        return productRepository.findAll();
    } // gets all products from the database

}
