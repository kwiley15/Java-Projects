package com.example.javaAssignment1.Repository;

import com.example.javaAssignment1.product;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository //marks this interface as a spring boot repository
public interface ProductRepository extends JpaRepository<product, Long> {
}
