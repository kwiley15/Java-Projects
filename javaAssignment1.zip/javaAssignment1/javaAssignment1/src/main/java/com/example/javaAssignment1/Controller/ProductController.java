package com.example.javaAssignment1.Controller;


import com.example.javaAssignment1.Service.ProductService;
import com.example.javaAssignment1.product;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController //marks this as a rest controller to handel HTTP requests
@RequestMapping("/products") //base endpoint for all endpoints
public class ProductController {

    @Autowired// injecting to handle product operations
    private ProductService productService;


    @PostMapping //endpoint to create a new product
    public product createProduct(@RequestBody product product) {
        return productService.createProduct(product); // converts json body into a product object and saves it
    }


    @GetMapping("/{id}") //endpoint to get a product by its id
    public product getProduct(@PathVariable Long id) {
        return productService.getProduct(id);
    }


    @PutMapping("/{id}") //endpoint to update an existing product
    public product updateProduct(@PathVariable Long id, @RequestBody product product) {
        return productService.updateProduct(id, product);
    }


    @DeleteMapping("/{id}") //endpoint to delete a product by its ID
    public void deleteProduct(@PathVariable Long id) {
        productService.deleteProduct(id);
    }


    @GetMapping //endpoint to list all products
    public List<product> getAllProducts() {
        return productService.getAllProducts();
    }


}
