package com.example.javaAssignment1;


import jakarta.persistence.*;

import java.util.Date;
/*this represents a product entity for the database*/
@Entity
public class product { // class representing the products

    @Id // marks ID as primary key
    @GeneratedValue(strategy = GenerationType.IDENTITY) // auto generate unique ids for the primary key
    private Long id; // identifier for the product

    private String name; // name of the product

    @Column(length = 500) // limits the description filed to 500 characters
    private String description; // detailed description for the product

    private Date timestamp; // stores date and time when a product was added

    private double price; // the price of the product

    private int quantity; // the quantity of the product(s)

    public product() {} // default constructor required by JPA (get an error without this)

    public product(String name, String description, Date timestamp, int quantity, double price) {
        this.name = name;
        this.description = description;
        this.timestamp = timestamp;
        this.quantity = quantity;
        this.price = price;
    }


    public String getName() { //gets the product name
        return name; // return the name of the product
    }

    public void setName(String name) { //sets the product name
        this.name = name; //
    }

    public String getDescription() { //gets the products description
        return description;
    }

    public void setDescription(String description) { //sets the product description
        this.description = description;
    }

    public int getQuantity() { //gets the product quantity
        return quantity;
    }

    public void setQuantity(int quantity) { //sets the product quantity
        this.quantity = quantity;
    }

    public double getPrice() { //gets the price of the product
        return price;
    }

    public void setPrice(double price) { //sets the price of the product
        this.price = price;
    }

}
